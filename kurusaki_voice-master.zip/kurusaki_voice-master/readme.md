# This repository's purpose is just an example code for the video in playing audio from heroku. 

# This bot has a code that requires Youtube API Credentials
# To get your Youtube API Token follow the instructions in the links provided 
https://developers.google.com/youtube/v3/getting-started


To create your project and credentials 
https://console.cloud.google.com
